﻿using EmployeeApi.Models;
using Microsoft.EntityFrameworkCore;
using System.Collections.Generic;
using System.Reflection.Emit;

namespace EmployeeApi
{
    public class AppDbContext : DbContext
    {
        public AppDbContext(DbContextOptions<AppDbContext> options) : base(options)
        {
        }

        public DbSet<User> Users { get; set; }
        public DbSet<Employee> Employees { get; set; }

        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            //// Seed initial admin user
            //modelBuilder.Entity<User>().HasData(
            //    new User
            //    {
            //        Id = 1,
            //        Username = "admin",
            //        Password = BCrypt.Net.BCrypt.HashPassword("admin123"),
            //        Role = "Admin"
            //    }
            //);

            // Create index for searchable fields
            modelBuilder.Entity<Employee>()
                .HasIndex(e => e.Name)
                .IsClustered(false);

            modelBuilder.Entity<Employee>()
                .HasIndex(e => e.Department)
                .IsClustered(false);
        }
    }
}
