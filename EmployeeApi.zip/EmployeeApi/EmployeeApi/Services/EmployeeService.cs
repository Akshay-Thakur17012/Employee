﻿using EmployeeApi.Models;
using EmployeeApi.Services.IServices;
using EmployeeApi.ViewModel;
using Microsoft.Data.SqlClient;
using Microsoft.EntityFrameworkCore;

namespace EmployeeApi.Services
{
    public class EmployeeService : IEmployeeService
    {
        private readonly AppDbContext _context;

        public EmployeeService(AppDbContext context)
        {
            _context = context;
        }

        public async Task<PagedResult<Employee>> GetEmployeesAsync(int page, int pageSize, string search)
        {
            IQueryable<Employee> query;

            if (!string.IsNullOrWhiteSpace(search))
            {
                var parameter = new SqlParameter("@SearchTerm", search);
                var searched = await _context.Employees
                    .FromSqlRaw("EXEC sp_SearchEmployees @SearchTerm", parameter)
                    .ToListAsync();

                query = searched.AsQueryable();
            }
            else
            {
                query = _context.Employees.OrderBy(e => e.Name);
            }

            var totalCount = query.Count();

            var employees = query
                .Skip((page - 1) * pageSize)
                .Take(pageSize)
                .ToList();

            return new PagedResult<Employee>
            {
                Data = employees,
                TotalCount = totalCount,
                PageNumber = page,
                PageSize = pageSize
            };
        }

        public async Task<Employee> GetEmployeeByIdAsync(int id)
        {
            return await _context.Employees.FindAsync(id);
        }

        public async Task<Employee> AddEmployeeAsync(Employee employee)
        {
            var parameters = new[]
            {
            new SqlParameter("@Name", employee.Name),
            new SqlParameter("@Department", employee.Department),
            new SqlParameter("@Designation", employee.Designation),
            new SqlParameter("@Email", employee.Email),
            new SqlParameter("@Mobile", employee.Mobile)
        };

            await _context.Database.ExecuteSqlRawAsync("EXEC sp_InsertEmployee @Name, @Department, @Designation, @Email, @Mobile", parameters);

            var newId = await _context.Employees.MaxAsync(e => e.Id);
            employee.Id = newId;
            return employee;
        }

        public async Task<bool> UpdateEmployeeAsync(int id, Employee employee)
        {
            if (id != employee.Id) return false;

            employee.UpdatedDate = DateTime.Now;
            _context.Entry(employee).State = EntityState.Modified;

            try
            {
                await _context.SaveChangesAsync();
                return true;
            }
            catch (DbUpdateConcurrencyException)
            {
                return _context.Employees.Any(e => e.Id == id);
            }
        }

        public async Task<bool> DeleteEmployeeAsync(int id)
        {
            var employee = await _context.Employees.FindAsync(id);
            if (employee == null) return false;

            _context.Employees.Remove(employee);
            await _context.SaveChangesAsync();
            return true;
        }

        public async Task<IEnumerable<Employee>> SearchEmployeesAsync(string term)
        {
            var parameter = new SqlParameter("@SearchTerm", term);
            return await _context.Employees
                .FromSqlRaw("EXEC sp_SearchEmployees @SearchTerm", parameter)
                .ToListAsync();
        }
    }

}
