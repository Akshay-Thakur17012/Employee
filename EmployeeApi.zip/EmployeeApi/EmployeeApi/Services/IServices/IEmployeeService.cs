﻿using EmployeeApi.Models;
using EmployeeApi.ViewModel;

namespace EmployeeApi.Services.IServices
{
    public interface IEmployeeService
    {
        Task<PagedResult<Employee>> GetEmployeesAsync(int page, int pageSize, string search);
        Task<Employee> GetEmployeeByIdAsync(int id);
        Task<Employee> AddEmployeeAsync(Employee employee);
        Task<bool> UpdateEmployeeAsync(int id, Employee employee);
        Task<bool> DeleteEmployeeAsync(int id);
        Task<IEnumerable<Employee>> SearchEmployeesAsync(string term);
    }

}
