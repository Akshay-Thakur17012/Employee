﻿using EmployeeApi.Models;
using EmployeeApi.ViewModel;

namespace EmployeeApi.Services.IServices
{
    public interface ICommonService
    {
        Task<User> AuthenticateUser(string username, string password);
        Task<bool> RegisterUser(RegisterModel model);
    }
}
