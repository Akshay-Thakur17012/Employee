﻿using Dapper;
using EmployeeApi.Models;
using EmployeeApi.Services.IServices;
using EmployeeApi.ViewModel;
using Microsoft.Data.SqlClient;

namespace EmployeeApi.Services
{
    public class CommonService : ICommonService
    {
        private readonly string _connectionString;

        public CommonService(IConfiguration configuration)
        {
            _connectionString = configuration.GetConnectionString("DefaultConnection");
        }

        public async Task<User> AuthenticateUser(string username, string password)
        {
            using var connection = new SqlConnection(_connectionString);
            var user = await connection.QueryFirstOrDefaultAsync<User>(
                "SELECT * FROM Users WHERE Username = @Username", new { Username = username });

            if (user != null && BCrypt.Net.BCrypt.Verify(password, user.Password))
            {
                return user;
            }
            return null;
        }
        public async Task<bool> RegisterUser(RegisterModel model)
        {
            using var connection = new SqlConnection(_connectionString);

            model.Username = model.Username.Trim();
            // Check if username already exists
            var existingUser = await connection.QueryFirstOrDefaultAsync<User>(
                "SELECT * FROM Users WHERE Username = @Username", new { model.Username });

            if (existingUser != null)
            {
                return false; // Username already exists
            }

            // Insert new user
            var hashedPassword = BCrypt.Net.BCrypt.HashPassword(model.Password);

            var rowsAffected = await connection.ExecuteAsync(
                "INSERT INTO Users (Username, Password, Role) VALUES (@Username, @Password, @Role)",
                new
                {
                    Username = model.Username,
                    Password = hashedPassword,
                    Role = "User"
                });

            return rowsAffected > 0;
        }
    }
}
