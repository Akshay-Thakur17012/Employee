﻿using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

namespace EmployeeApi.Migrations
{
    /// <inheritdoc />
    public partial class Sp_EmployeeSearch : Migration
    {
        /// <inheritdoc />
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.Sql(@"
            CREATE PROCEDURE sp_SearchEmployees
                @SearchTerm NVARCHAR(100)
            AS
            BEGIN
                SELECT * FROM Employees 
                WHERE Name LIKE '%' + @SearchTerm + '%' 
                   OR Department LIKE '%' + @SearchTerm + '%'
                   OR Designation LIKE '%' + @SearchTerm + '%'
                   OR Email LIKE '%' + @SearchTerm + '%'
            END
        ");

            migrationBuilder.Sql(@"
            CREATE PROCEDURE sp_InsertEmployee
                @Name NVARCHAR(100),
                @Department NVARCHAR(100),
                @Designation NVARCHAR(100),
                @Email NVARCHAR(100),
                @Mobile NVARCHAR(20)
            AS
            BEGIN
                INSERT INTO Employees (Name, Department, Designation, Email, Mobile, JoiningDate)
                VALUES (@Name, @Department, @Designation, @Email, @Mobile, GETDATE())
                
                SELECT SCOPE_IDENTITY() AS Id
            END
        ");
        }

        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.Sql("DROP PROCEDURE IF EXISTS sp_SearchEmployees");
            migrationBuilder.Sql("DROP PROCEDURE IF EXISTS sp_InsertEmployee");
        }
    }
}
