﻿using Azure.Core;
using EmployeeApi.Models;
using EmployeeApi.Services;
using EmployeeApi.Services.IServices;
using EmployeeApi.ViewModel;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Identity.Data;
using Microsoft.AspNetCore.Mvc;
using Microsoft.IdentityModel.Tokens;
using System.IdentityModel.Tokens.Jwt;
using System.Security.Claims;
using System.Text;

namespace EmployeeApi.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class AuthController : ControllerBase
    {
        private readonly AppDbContext _context;
        private readonly ICommonService _commonService;
        private readonly JwtService _jwtService;
        public AuthController(AppDbContext context, ICommonService commonService, JwtService jwtService)
        {
            _context = context;
            _commonService = commonService;
            _jwtService = jwtService;
        }

        [HttpPost("login")]
        public async Task<IActionResult> Login([FromBody] LoginModel request)
        {
            var user = await _commonService.AuthenticateUser(request.Username, request.Password);
            if (user == null)
                return Unauthorized();

            var token = _jwtService.GenerateToken(user);
            return Ok(new LoginResponse { Token = token, Role = user.Role });
        }

        [HttpPost("register")]
        public async Task<IActionResult> Register([FromBody] RegisterModel model)
        {
            var registered = await _commonService.RegisterUser(model);

            if (!registered)
            {
                return BadRequest("Username already exists");
            }

            return Ok(new { Message = "User registered successfully" });
        }
    }
}
